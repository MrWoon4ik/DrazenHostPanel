import pydactyl

client = pydactyl.PterodactylClient('https://panel.drazenhost.pp.ua', 'ptla_8ArOD2sGIYaxUskiD4av9WfDlnQRHt2d7vprV2YgFCG')

name = "test"
email = "vladpika51@gmail.com"
stype = "python"


def create_free(name, email, stype):
	usr = client.user.list_users(email=email)
	try:
		if usr[0]['attributes'].get('id'):
			user_id = usr[0]['attributes']['id']
		else:
			return False
	except:
		return False

	if stype == "minecraft":
		nest_id = 1
		egg_id = 1
		docker_image = "ghcr.io/pterodactyl/yolks:java_8"
	if stype == "python":
		nest_id = 5
		egg_id = 15
		docker_image = "quay.io/yajtpg/pterodactyl-images:python-3.11"

	ram = 2000
	swap = 0
	disk = 5000
	location = 1
	ports_range = ['25500-25599']
	cpu_limit = 75

	client.servers.create_server(
		name=name,
		user_id=user_id,
		nest_id=nest_id,
		egg_id=egg_id,
		memory_limit=ram,
		swap_limit=swap,
		disk_limit=disk,
		location_ids=[location],
		port_range=ports_range,
		environment={
		    "SERVER_JARFILE": "server.jar",
		    "MINECRAFT_VERSION": "1.12.2",
		},
		cpu_limit=cpu_limit,
		io_limit=500,
		database_limit=1,
		allocation_limit=3,
		backup_limit=0,
		docker_image=docker_image,
		startup_cmd=None,
		dedicated_ip=False,
		start_on_completion=True,
		oom_disabled=False,
		default_allocation=None,
		additional_allocations=None,
		description=None
	)

if __name__ == "__main__":
	create_free(name, email, stype)

