import requests

class OAuth:
    client_id = "1074581841622872174"
    client_secret = "QTsSL4F5OhqwD7cNhC5UgGxhBkJoIs0k"
    redirect_uri = "http://panel.drazenhost.pp.ua/get_free_server/get_srv"
    scope = "email+guilds.join+guilds+identify"
    discord_login_url = f"https://discord.com/api/oauth2/authorize?client_id={client_id}&redirect_uri={redirect_uri}&response_type=code&scope={scope}"
    discord_token_url = "https://discord.com/api/oauth2/token"
    discord_api_url = "https://discord.com/api"
 
 
    @staticmethod
    def get_access_token(code):
        payload = {
            "client_id": OAuth.client_id,
            "client_secret": OAuth.client_secret,
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": OAuth.redirect_uri,
            "scope": OAuth.scope
        }
 
        access_token = requests.post(url = OAuth.discord_token_url, data = payload).json()
        return access_token.get("access_token")
 
 
    @staticmethod
    def get_user_json(access_token):
        url = f"{OAuth.discord_api_url}/users/@me"
        headers = {"Authorization": f"Bearer {access_token}"}
 
        user_object = requests.get(url = url, headers = headers).json()
        return user_object