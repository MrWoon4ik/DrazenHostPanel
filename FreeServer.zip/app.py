from flask import Flask, render_template, request, redirect
from OAuth2c import OAuth
import free

app = Flask(__name__)

@app.route('/get_free_server')
def index():
    return render_template('discord.html')

@app.route('/get_free_server/get_srv')
def get_server():
	code = request.args.get('code')
	if not code:
		return render_template('discord.html')
	else:
		print('f')
		token = OAuth.get_access_token(code.strip())
		user = OAuth.get_user_json(token)
		if token == None or user == None:
			return render_template('discord.html', error='Вы не привязали Discord.')
		uid = user.get('id')
		uemail = user.get('email')
		with open('users.txt', 'r', encoding='utf-8') as f:
			for line in f.readlines():
				ls = line.strip().split(':')
				uuid = ls[0]
				uuemail = ls[1]
				if uid == uuid or uemail == uuemail:
					return render_template('discord.html', error='Вы не имеете права на бесплатный сервер. Если вы считаете, что это ошибка, свяжитесь по чату.')
		return render_template('index.html', discord=token)

@app.route('/get_free_server/get')
def get_srv():
	token = request.args.get('discord')
	name = request.args.get('name')
	stype = request.args.get('type')
	user = OAuth.get_user_json(token)
	uid = user.get('id')
	uemail = user.get('email')
	with open('users.txt', 'r', encoding='utf-8') as f:
		for line in f.readlines():
			ls = line.strip().split(':')
			uuid = ls[0]
			uuemail = ls[1]
			if uid == uuid or uemail == uuemail:
				return render_template('discord.html', error='Вы не имеете права на бесплатный сервер. Если вы считаете, что это ошибка, свяжитесь по чату.')
	if free.create_free(name, uemail, stype) == False:
		return render_template('discord.html', error='Email адрес вашего аккаунта Discord не зарегестрирован. Проверьте, совпадает ли адрес дискорд аккаунта, с адресом в панели, и если нет - измените его в "Мой профиль".')
	else:
		with open('users.txt', 'a', encoding='utf-8') as f:
			f.write(f'{uid}:{uemail}')
		return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)